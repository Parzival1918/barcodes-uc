# Barcodes python module

In progress...

Thanks to Melisa for her precious help.